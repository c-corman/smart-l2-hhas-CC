# Reference Implementations - SMART L2 HHAS v0.1.0

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Reference Implementations**

## Reference Implementations

This page includes sample resources that can be leveraged to support the implementation of SMART Guidelines for HHAS. Content is for demonstration purposes only.

Additional relevant resources are included in the [References](references.md) and [Dependencies](dependencies.md).

### Reference applications

### Reference architecture

